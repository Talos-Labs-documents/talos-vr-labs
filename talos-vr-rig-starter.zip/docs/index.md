# TALOS VR Rig Docs

Welcome to the **TALOS VR Rig** build docs.

- Mechanical build guide
- Electrical wiring
- Firmware flashing
- Unreal/Unity integration
- Safety best practices
