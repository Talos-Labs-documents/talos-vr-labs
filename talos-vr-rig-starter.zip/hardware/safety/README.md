# Safety Guidelines

- **E-Stop required** (NC wiring) inline with motor power.
- **Harness/seatbelt** mandatory for all users.
- **Hardware ceiling** in firmware must remain ≤ mechanical spec.
- Keep fingers/clothing away from moving parts; use guards.
- Run first tests with **no rider**, then with sandbags, then a rider.
