# Code of Conduct

Be respectful. Safety-first. No harassment or hate speech. Report issues via GitHub.
